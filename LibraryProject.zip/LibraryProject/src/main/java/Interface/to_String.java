package Interface;


import java.io.Serializable;

public interface to_String extends Serializable {

    String toString();
}
